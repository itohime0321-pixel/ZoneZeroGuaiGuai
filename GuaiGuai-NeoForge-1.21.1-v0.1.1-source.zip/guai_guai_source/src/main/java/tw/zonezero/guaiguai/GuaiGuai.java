package tw.zonezero.guaiguai;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.function.Supplier;

@Mod(GuaiGuai.MOD_ID)
public final class GuaiGuai {
    public static final String MOD_ID = "guaiguai";
    private static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    private static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    private static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final DeferredBlock<AuraBlock> GREEN = register("green", () -> MobEffects.LUCK, 5);
    public static final DeferredBlock<AuraBlock> YELLOW = register("yellow", () -> MobEffects.DIG_SPEED, 5);
    public static final DeferredBlock<AuraBlock> RED = register("red", () -> MobEffects.DAMAGE_BOOST, 3);
    public static final DeferredBlock<AuraBlock> BLUE = register("blue", () -> MobEffects.WATER_BREATHING, 5);
    public static final DeferredBlock<AuraBlock> PURPLE = register("purple", () -> MobEffects.NIGHT_VISION, 5);
    public static final DeferredBlock<AuraBlock> BLACK = register("black", () -> MobEffects.DAMAGE_RESISTANCE, 3);

    private static DeferredBlock<AuraBlock> register(String color, Supplier<Holder<MobEffect>> effect, int minutes) {
        String name = color + "_guaiguai";
        DeferredBlock<AuraBlock> block = BLOCKS.register(name, () -> new AuraBlock(
                BlockBehaviour.Properties.of().strength(0.25F).sound(SoundType.WOOD).noOcclusion(), color, effect, minutes));
        ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    public GuaiGuai(IEventBus bus) {
        TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.guaiguai.main"))
            .icon(() -> new ItemStack(GREEN.get()))
            .displayItems((parameters, output) -> {
                output.accept(GREEN.get()); output.accept(YELLOW.get()); output.accept(RED.get());
                output.accept(BLUE.get()); output.accept(PURPLE.get()); output.accept(BLACK.get());
            }).build());
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
