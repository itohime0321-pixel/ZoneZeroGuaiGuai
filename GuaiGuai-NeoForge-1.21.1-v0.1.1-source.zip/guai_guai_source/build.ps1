$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$version = '8.12.1'
$cache = Join-Path $PSScriptRoot '.gradle-bootstrap'
$homeDir = Join-Path $cache "gradle-$version"
$gradle = Join-Path $homeDir 'bin\gradle.bat'
if (-not (Test-Path $gradle)) {
    New-Item -ItemType Directory -Force -Path $cache | Out-Null
    $zip = Join-Path $cache "gradle-$version-bin.zip"
    Invoke-WebRequest "https://services.gradle.org/distributions/gradle-$version-bin.zip" -OutFile $zip
    $checksum = (Invoke-RestMethod "https://services.gradle.org/distributions/gradle-$version-bin.zip.sha256").Trim()
    if ((Get-FileHash -Algorithm SHA256 $zip).Hash.ToLowerInvariant() -ne $checksum.ToLowerInvariant()) { throw 'Gradle checksum mismatch' }
    Expand-Archive -Path $zip -DestinationPath $cache -Force
}
& $gradle --no-daemon build
if ($LASTEXITCODE -ne 0) { throw 'Gradle build failed; see log above.' }
Get-ChildItem (Join-Path $PSScriptRoot 'build\libs') -Filter '*.jar'
