package tw.zonezero.guaiguai;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import java.util.List;
import java.util.function.Supplier;

public final class AuraBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    private static final int INTERVAL = 60 * 20;
    private static final double RADIUS = 3.0;
    private static final VoxelShape NS = Block.box(2.9, 0, 4, 13.1, 14, 13.5);
    private static final VoxelShape SOUTH = Block.box(2.9, 0, 2.5, 13.1, 14, 12);
    private static final VoxelShape EAST = Block.box(2.5, 0, 2.9, 12, 14, 13.1);
    private static final VoxelShape WEST = Block.box(4, 0, 2.9, 13.5, 14, 13.1);
    private final String color;
    private final Supplier<Holder<MobEffect>> effect;
    private final int duration;

    public AuraBlock(Properties properties, String color, Supplier<Holder<MobEffect>> effect, int minutes) {
        super(properties);
        this.color = color;
        this.effect = effect;
        this.duration = minutes * 60 * 20;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }
    @Override public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }
    @Override protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }
    @Override protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
    @Override protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return switch (state.getValue(FACING)) {
            case NORTH -> NS;
            case SOUTH -> SOUTH;
            case EAST -> EAST;
            case WEST -> WEST;
            default -> NS;
        };
    }

    // Scheduled block ticks are server-side and persisted with chunks. No block entity or global scan.
    @Override protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moving) {
        super.onPlace(state, level, pos, oldState, moving);
        if (level instanceof ServerLevel server && !oldState.is(this)) {
            server.scheduleTick(pos, this, 1 + Math.floorMod(pos.hashCode(), INTERVAL));
        }
    }
    @Override protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!level.getBlockState(pos).is(this)) return;
        Vec3 center = Vec3.atCenterOf(pos);
        AABB area = new AABB(center.x - RADIUS, center.y - RADIUS, center.z - RADIUS,
                             center.x + RADIUS, center.y + RADIUS, center.z + RADIUS);
        Holder<MobEffect> type = effect.get();
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, area,
                p -> p.isAlive() && !p.isSpectator() && p.position().distanceToSqr(center) <= RADIUS * RADIUS)) {
            MobEffectInstance current = player.getEffect(type);
            // Do not overwrite a stronger effect or reduce a longer remaining duration.
            if (current == null || (current.getAmplifier() == 0 && !current.isInfiniteDuration()
                    && current.getDuration() <= duration)) {
                player.addEffect(new MobEffectInstance(type, duration, 0, true, false, true));
            }
        }
        level.scheduleTick(pos, this, INTERVAL);
    }
    @Override public void appendHoverText(ItemStack stack, Item.TooltipContext context,
                                          List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.guaiguai." + color).withStyle(ChatFormatting.GREEN));
        tooltip.add(Component.translatable("tooltip.guaiguai.aura").withStyle(ChatFormatting.GRAY));
    }
}
