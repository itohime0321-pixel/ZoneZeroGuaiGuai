乖乖模組 0.1.1 — NeoForge 1.21.1 原始碼預覽版
================================================
本包是完整的第一版開發專案，尚未經 Gradle 編譯及遊戲實測，並非可直接放進 mods 的 JAR。
Java 21；不依賴 KubeJS。測試目標 NeoForge 21.1.172（可在 gradle.properties 改為伺服器的 21.1.x 版本）。

【Windows 編譯方式】
1. 完整解壓縮 ZIP，確認 JDK 21 已安裝（命令提示字元 java -version）。
2. 連線至網際網路，雙擊 build.bat。腳本下載官方 Gradle 8.12.1 並比對 SHA256，接著下載編譯依賴。
3. 若顯示 BUILD COMPLETE，於 build\libs 找到 guaiguai-neoforge-1.21.1-0.1.1.jar。
4. 先在單機 NeoForge 1.21.1 測試，再將相同 JAR 裝至伺服器及所有玩家的 mods 資料夾。
若使用 GitHub，已附 .github/workflows/build.yml；上傳完整專案（包含隱藏的 .github 目錄）後，可從 Actions 的成功工作流程下載 artifact。

【玩法】
創造模式新增「乖乖」分類。六種方塊不佔滿整格，皆使用一個方塊位置，放置時面朝玩家。
綠色（奶油椰子）幸運 I 5 分鐘；黃色挖掘加速 I 5 分鐘；紅色力量 I 3 分鐘；藍色水下呼吸 I 5 分鐘；紫色夜視 I 5 分鐘；黑色抗性提升 I 3 分鐘。
以方塊中心至玩家腳部位置的三維直線距離計算，半徑 3 格。每 1200 tick（正常 TPS 下 60 秒）觸發一次；各方塊首次觸發錯開，放置後最多等待一分鐘；離開後效果自然倒數。同種類不疊加，不覆蓋更強或較長的效果；不同種類可同時存在。效果不產生大量玩家粒子。
已設計一般挖掘掉落本身；爆炸依原版爆炸掉落規則。尚未加入合成配方、戰利品箱或交易，由管理員決定取得方式。不是可食用物品。

【物品 ID】
/give @s guaiguai:green_guaiguai
/give @s guaiguai:yellow_guaiguai
/give @s guaiguai:red_guaiguai
/give @s guaiguai:blue_guaiguai
/give @s guaiguai:purple_guaiguai
/give @s guaiguai:black_guaiguai

【測試清單】
- 六色創造欄、手持、放置及四個方向的模型是否正確。
- 生存模式打掉是否回收；存檔重開後光環是否繼續；移除後是否停止刷新。
- 半徑內外、不同高度、多人、同色多包、不同顏色、原有更強藥水。
- 專用伺服器啟動、客戶端登入及放置。

【資源與開發狀態】
六款正面貼圖依使用者給定概念圖重整為 64x64 像素，綠色改為椰子；側面、背面及封口另行製作；橡木支架使用原版貼圖。texture_preview.png 為正面貼圖預覽，不是遊戲截圖。
靜態檢查已通過：JSON 格式、模型頂點在單格內、所有貼圖及掉落表路徑、四方向方塊狀態及中英語系。沒有進行 Java 編譯或遊戲實測，因目前環境無法下載 Gradle / NeoForge 依賴。
本模組為非官方同人設計，與乖乖品牌無關；公開發佈前請確認相關商標及圖像使用權利。
