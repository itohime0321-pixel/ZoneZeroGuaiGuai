@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
if errorlevel 1 (
  echo BUILD FAILED. See errors above.
) else (
  echo BUILD COMPLETE. Check build\libs.
)
pause
